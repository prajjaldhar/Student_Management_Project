"""
cx_Freeze command line tool (enable python -m cx_Freeze syntax)
"""

import cx_Freeze.cli

if __name__ == "__main__":
    cx_Freeze.cli.main()
